import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles,
  MapPin,
  Compass,
  Heart,
  Loader2,
  AlertTriangle,
  Code2,
  RefreshCw,
  ClipboardCopy,
  ArrowLeft,
  Sunrise,
  Sun,
  Sunset,
  Utensils,
  Lightbulb,
  Camera,
  Leaf,
  Info,
  Route,
  Wallet,
} from "lucide-react";

/**
 * Module 6: AI Itinerary Generation
 *
 * Renders AI-generated itinerary with clear day-level structure
 * and activity blocks following backend schema v2.0
 */
export default function ItineraryGeneration() {
  const [configuration, setConfiguration] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [itinerary, setItinerary] = useState(null);
  const [showRawJson, setShowRawJson] = useState(false);
  const [copied, setCopied] = useState(false);

  // ============================================================================
  // LOAD CONFIGURATION FROM PREVIOUS MODULE
  // ============================================================================
  useEffect(() => {
    const stored = sessionStorage.getItem("tripConfiguration");
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setConfiguration(parsed);
        console.log("✅ Configuration loaded from sessionStorage");
      } catch (err) {
        console.error("❌ Failed to parse configuration:", err);
      }
    } else {
      console.warn("⚠️ No configuration found in sessionStorage");
    }
  }, []);

  // ============================================================================
  // GENERATE ITINERARY
  // ============================================================================
  const handleGenerateItinerary = async () => {
    if (!configuration) return;

    setLoading(true);
    setError(null);
    setItinerary(null);

    try {
      const response = await fetch("http://127.0.0.1:8000/api/itinerary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(configuration),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.detail || "Failed to generate itinerary");
      }

      const data = await response.json();
      setItinerary(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // ============================================================================
  // HELPER: Get period icon
  // ============================================================================
  const getPeriodIcon = (period) => {
    const icons = {
      morning: Sunrise,
      afternoon: Sun,
      evening: Sunset,
    };
    return icons[period] || MapPin;
  };

  // ============================================================================
  // HELPER: Get activity type badge colors
  // ============================================================================
  const getActivityBadge = (type) => {
    const styles = {
      relaxation: "bg-blue-50 text-blue-700 border-blue-100",
      food: "bg-orange-50 text-orange-700 border-orange-100",
      sightseeing: "bg-purple-50 text-purple-700 border-purple-100",
      culture: "bg-green-50 text-green-700 border-green-100",
      photography: "bg-pink-50 text-pink-700 border-pink-100",
      beach: "bg-cyan-50 text-cyan-700 border-cyan-100",
      adventure: "bg-red-50 text-red-700 border-red-100",
      history: "bg-amber-50 text-amber-700 border-amber-100",
      music: "bg-indigo-50 text-indigo-700 border-indigo-100",
      nature: "bg-emerald-50 text-emerald-700 border-emerald-100",
      shopping: "bg-fuchsia-50 text-fuchsia-700 border-fuchsia-100",
    };
    return styles[type] || "bg-slate-100 text-slate-700 border-slate-200";
  };

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(itinerary, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // ============================================================================
  // RENDER: MISSING CONFIGURATION
  // ============================================================================
  if (!configuration) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-purple-50 flex items-center justify-center py-8 px-4">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white rounded-2xl shadow-xl border border-slate-100 p-8 text-center"
        >
          <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-gradient-to-br from-orange-500 via-pink-500 to-purple-600 flex items-center justify-center">
            <Info className="w-7 h-7 text-white" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">
            Missing Configuration
          </h2>
          <p className="text-sm text-slate-600 mb-6">
            No trip configuration found. Please complete the configuration
            step first.
          </p>
          <button
            onClick={() => (window.location.href = "/trip-configuration")}
            className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-orange-500 to-pink-600 text-white rounded-full font-semibold hover:shadow-lg hover:scale-[1.02] transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            Return to Configuration
          </button>
        </motion.div>
      </div>
    );
  }

  // ============================================================================
  // RENDER: MAIN UI
  // ============================================================================
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-purple-50 py-10 px-4">
      <div className="max-w-4xl mx-auto">
        {/* ====================================================================== */}
        {/* HEADER */}
        {/* ====================================================================== */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <span className="inline-flex items-center gap-2 text-xs font-semibold tracking-wide uppercase text-orange-600 bg-orange-100 px-3 py-1 rounded-full mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            Step 3 of 3
          </span>
          <h1 className="text-3xl font-bold text-slate-900 mb-1">
            Your AI{" "}
            <span className="bg-gradient-to-r from-orange-600 to-purple-600 bg-clip-text text-transparent">
              Itinerary
            </span>
          </h1>
          <p className="text-slate-600">
            A personalized day-by-day plan, crafted from your preferences
          </p>
        </motion.div>

        {/* ====================================================================== */}
        {/* CONFIGURATION SUMMARY */}
        {/* ====================================================================== */}
        {!itinerary && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 mb-6"
          >
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              Your Trip Configuration
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
              <div className="bg-blue-50 rounded-xl p-4">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-blue-700 uppercase mb-1.5">
                  <Route className="w-3.5 h-3.5" />
                  Route
                </div>
                <div className="text-sm font-bold text-slate-900">
                  {configuration.trip_summary.source} →{" "}
                  {configuration.trip_summary.destination}
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  {configuration.trip_summary.days} days •{" "}
                  {configuration.trip_summary.travel_mode}
                </div>
              </div>

              <div className="bg-green-50 rounded-xl p-4">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-green-700 uppercase mb-1.5">
                  <Wallet className="w-3.5 h-3.5" />
                  Pace & Budget
                </div>
                <div className="text-sm font-bold text-slate-900 capitalize">
                  {configuration.constraints.pace} Pace
                </div>
                <div className="text-xs text-slate-500 mt-1 capitalize">
                  {configuration.constraints.budget} •{" "}
                  {configuration.constraints.places_per_day} places/day
                </div>
              </div>

              <div className="bg-orange-50 rounded-xl p-4">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-orange-700 uppercase mb-1.5">
                  <Heart className="w-3.5 h-3.5" />
                  Interests
                </div>
                <div className="text-sm font-bold text-slate-900">
                  {configuration.interests.length} Selected
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  {configuration.interests.slice(0, 2).join(", ")}
                  {configuration.interests.length > 2 &&
                    ` +${configuration.interests.length - 2}`}
                </div>
              </div>
            </div>

            <button
              onClick={handleGenerateItinerary}
              disabled={loading}
              className="w-full inline-flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-purple-600 disabled:from-slate-300 disabled:to-slate-300 disabled:cursor-not-allowed text-white font-bold py-3.5 px-6 rounded-full hover:shadow-lg hover:scale-[1.01] transition-all"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Generate My Itinerary
                </>
              )}
            </button>
          </motion.div>
        )}

        {/* ====================================================================== */}
        {/* LOADING STATE */}
        {/* ====================================================================== */}
        <AnimatePresence>
          {loading && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="bg-white rounded-2xl shadow-sm border border-slate-100 p-10 text-center"
            >
              <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-gradient-to-br from-orange-500 via-pink-500 to-purple-600 flex items-center justify-center">
                <Loader2 className="w-7 h-7 text-white animate-spin" />
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-1.5">
                Generating Your Itinerary
              </h3>
              <p className="text-slate-600 text-sm">
                AI is crafting your {configuration.trip_summary.days}-day
                itinerary for {configuration.trip_summary.destination}...
              </p>
              <p className="text-xs text-slate-400 mt-3">
                This may take 10–30 seconds
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ====================================================================== */}
        {/* ERROR STATE */}
        {/* ====================================================================== */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="bg-red-50 border border-red-100 rounded-2xl p-6 mb-6"
            >
              <div className="flex items-start gap-4">
                <AlertTriangle className="w-6 h-6 text-red-500 shrink-0" />
                <div className="flex-1">
                  <h3 className="text-base font-semibold text-red-900 mb-1">
                    Generation Failed
                  </h3>
                  <p className="text-sm text-red-700 mb-4">{error}</p>
                  <button
                    onClick={handleGenerateItinerary}
                    className="inline-flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-full text-sm transition-colors"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Try Again
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ====================================================================== */}
        {/* ITINERARY DISPLAY */}
        {/* ====================================================================== */}
        <AnimatePresence>
          {itinerary && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-5"
            >
              {/* Trip Header */}
              <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="px-6 py-5 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600">
                  <h2 className="text-2xl font-bold text-white">
                    {itinerary.destination} · {itinerary.days} Days
                  </h2>
                  <p className="text-white/80 mt-1 capitalize text-sm">
                    {itinerary.overall_style.pace} pace •{" "}
                    {itinerary.overall_style.budget} budget
                  </p>
                </div>

                <div className="p-6">
                  <div className="flex flex-wrap gap-2 mb-5">
                    {configuration.interests.slice(0, 6).map((interest, idx) => (
                      <span
                        key={idx}
                        className="bg-slate-100 text-slate-600 px-3 py-1 rounded-full text-xs font-medium"
                      >
                        {interest}
                      </span>
                    ))}
                  </div>

                  <div className="flex flex-wrap gap-2.5 border-t border-slate-100 pt-4">
                    <button
                      onClick={() => setShowRawJson(!showRawJson)}
                      className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium py-2 px-4 rounded-full text-sm transition-colors"
                    >
                      <Code2 className="w-3.5 h-3.5" />
                      {showRawJson ? "Hide" : "Show"} Raw JSON
                    </button>

                    <button
                      onClick={handleGenerateItinerary}
                      className="inline-flex items-center gap-1.5 bg-gradient-to-r from-orange-500 to-pink-600 text-white font-medium py-2 px-4 rounded-full text-sm hover:shadow-md transition-all"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      Regenerate
                    </button>

                    <button
                      onClick={handleCopyJson}
                      className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium py-2 px-4 rounded-full text-sm transition-colors"
                    >
                      <ClipboardCopy className="w-3.5 h-3.5" />
                      {copied ? "Copied!" : "Copy JSON"}
                    </button>
                  </div>
                </div>
              </div>

              {/* Raw JSON View */}
              <AnimatePresence>
                {showRawJson && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="bg-slate-900 rounded-2xl p-6 overflow-hidden"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-white font-semibold text-sm">
                        Raw JSON Response
                      </h3>
                      <button
                        onClick={() => setShowRawJson(false)}
                        className="text-slate-400 hover:text-white text-lg leading-none"
                      >
                        ✕
                      </button>
                    </div>
                    <pre className="text-green-400 text-xs font-mono overflow-auto max-h-96">
                      {JSON.stringify(itinerary, null, 2)}
                    </pre>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* ================================================================== */}
              {/* DAY-BY-DAY ITINERARY */}
              {/* ================================================================== */}
              {itinerary.itinerary.map((day, dayIdx) => (
                <motion.div
                  key={dayIdx}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: dayIdx * 0.05 }}
                  className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden"
                >
                  {/* DAY HEADER */}
                  <div className="bg-gradient-to-r from-slate-800 to-slate-900 text-white p-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-pink-600 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-lg font-bold text-white">
                          {day.day}
                        </span>
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold mb-0.5">
                          {day.day_theme}
                        </h3>
                        <p className="text-slate-300 text-sm">
                          {day.day_summary}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* ACTIVITY BLOCKS */}
                  <div className="divide-y divide-slate-100">
                    {day.blocks.map((block, blockIdx) => {
                      const PeriodIcon = getPeriodIcon(block.period);
                      return (
                        <div key={blockIdx} className="p-6">
                          {/* BLOCK HEADER */}
                          <div className="flex items-start gap-4 mb-4">
                            <div className="w-10 h-10 rounded-full bg-orange-50 flex items-center justify-center flex-shrink-0">
                              <PeriodIcon className="w-5 h-5 text-orange-500" />
                            </div>
                            <div className="flex-1">
                              <div className="flex flex-wrap items-center gap-2 mb-2">
                                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                                  {block.period}
                                </span>
                                <span className="text-slate-300">•</span>
                                <span className="text-sm text-slate-500 font-medium">
                                  {block.time_window}
                                </span>
                                <span
                                  className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getActivityBadge(
                                    block.activity_type
                                  )}`}
                                >
                                  {block.activity_type}
                                </span>
                              </div>

                              {/* ACTIVITY TITLE */}
                              <h4 className="text-lg font-bold text-slate-900 mb-2">
                                {block.title}
                              </h4>

                              {/* DESCRIPTION */}
                              <p className="text-slate-600 leading-relaxed text-sm">
                                {block.description}
                              </p>
                            </div>
                          </div>

                          {/* OPTIONAL FIELDS */}
                          <div className="grid grid-cols-1 gap-2.5 mt-4 ml-14">
                            {/* MEAL INFO */}
                            {block.meal && block.meal.meal_type !== "none" && (
                              <div className="bg-orange-50 border border-orange-100 rounded-xl p-3.5">
                                <div className="flex items-start gap-2.5">
                                  <Utensils className="w-4 h-4 text-orange-500 mt-0.5 shrink-0" />
                                  <div className="flex-1">
                                    <div className="text-xs font-bold text-orange-900 uppercase mb-0.5">
                                      {block.meal.meal_type}
                                    </div>
                                    <p className="text-sm text-orange-800 capitalize flex items-center gap-1.5 flex-wrap">
                                      {block.meal.cuisine_type} •{" "}
                                      {block.meal.dining_style}
                                      {block.meal.veg_friendly && (
                                        <span className="inline-flex items-center gap-1 text-green-700">
                                          <Leaf className="w-3 h-3" />
                                          Veg-friendly
                                        </span>
                                      )}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            )}

                            {/* LOGISTICS HINT */}
                            {block.logistics_hint && (
                              <div className="bg-blue-50 border border-blue-100 rounded-xl p-3.5">
                                <div className="flex items-start gap-2.5">
                                  <Lightbulb className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
                                  <div className="flex-1">
                                    <div className="text-xs font-bold text-blue-900 uppercase mb-0.5">
                                      Logistics
                                    </div>
                                    <p className="text-sm text-blue-800">
                                      {block.logistics_hint}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            )}

                            {/* PHOTOGRAPHY NOTE */}
                            {block.photography_note &&
                              block.photography_note !== "None." && (
                                <div className="bg-purple-50 border border-purple-100 rounded-xl p-3.5">
                                  <div className="flex items-start gap-2.5">
                                    <Camera className="w-4 h-4 text-purple-500 mt-0.5 shrink-0" />
                                    <div className="flex-1">
                                      <div className="text-xs font-bold text-purple-900 uppercase mb-0.5">
                                        Photography Tip
                                      </div>
                                      <p className="text-sm text-purple-800">
                                        {block.photography_note}
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </motion.div>
              ))}

              {/* FOOTER */}
              <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 text-center">
                <p className="text-slate-600 mb-4 text-sm">
                  Your itinerary is ready. Generate another version or return
                  to configuration.
                </p>
                <div className="flex flex-wrap gap-3 justify-center">
                  <button
                    onClick={handleGenerateItinerary}
                    className="inline-flex items-center gap-2 bg-gradient-to-r from-orange-500 to-purple-600 text-white font-semibold py-2.5 px-6 rounded-full hover:shadow-lg hover:scale-[1.02] transition-all"
                  >
                    <RefreshCw className="w-4 h-4" />
                    Generate Another
                  </button>
                  <button
                    onClick={() => (window.location.href = "/trip-configuration")}
                    className="inline-flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2.5 px-6 rounded-full transition-colors"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back to Config
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
