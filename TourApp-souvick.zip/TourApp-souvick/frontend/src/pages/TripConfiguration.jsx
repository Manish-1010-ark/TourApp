import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  MapPin,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Sparkles,
  Feather,
  Compass,
  Zap,
  Coins,
  Gem,
  Wallet,
  Info,
  Loader2,
  ChevronDown,
  Route,
  Car,
  CalendarDays,
} from "lucide-react";

/**
 * TripConfiguration - Two-section configuration page
 *
 * SECTION 1: Details Verification (must be confirmed before proceeding)
 * SECTION 2: Final Constraints (pace, budget, interests, preferences)
 *
 * Data Flow:
 * sessionStorage (tripData) → Section 1 (verify) → Section 2 (configure) → API
 */
export default function TripConfiguration() {
  // ============================================================================
  // SECTION 1: TRIP DATA FROM PREVIOUS STEPS
  // ============================================================================
  const [tripData, setTripData] = useState(null);
  const [detailsConfirmed, setDetailsConfirmed] = useState(false);

  // Load trip data from sessionStorage on mount
  useEffect(() => {
    const stored = sessionStorage.getItem("tripData");
    if (stored) {
      try {
        setTripData(JSON.parse(stored));
      } catch (err) {
        console.error("Failed to parse trip data:", err);
      }
    }
  }, []);

  // ============================================================================
  // SECTION 2: CONFIGURATION STATE
  // ============================================================================
  const [pace, setPace] = useState("balanced");
  const [budget, setBudget] = useState("premium");
  const [suggestedInterests, setSuggestedInterests] = useState([]);
  const [selectedInterests, setSelectedInterests] = useState([]);
  const [constraints, setConstraints] = useState({
    avoid_early_mornings: false,
    prefer_less_walking: false,
    family_friendly: false,
    vegetarian_friendly: false,
    photography_focus: false,
  });
  const [aiModel, setAiModel] = useState("gemini-flash-latest");

  // UI state
  const [loadingInterests, setLoadingInterests] = useState(false);
  const [loadingConfig, setLoadingConfig] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);

  // ============================================================================
  // INTEREST SUGGESTION (AI-POWERED)
  // ============================================================================
  const handleSuggestInterests = async () => {
    if (!tripData) return;

    setLoadingInterests(true);
    setError(null);

    try {
      const response = await fetch(
        "http://127.0.0.1:8000/api/interests/suggest",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            source: tripData.source.name,
            destination: tripData.destination.name,
            travel_mode: tripData.travel_mode,
            days: tripData.days,
          }),
        }
      );

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.detail || "Failed to suggest interests");
      }

      const data = await response.json();
      setSuggestedInterests(data.interests);

      // Auto-select first 5 for convenience
      setSelectedInterests(data.interests.slice(0, 5));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoadingInterests(false);
    }
  };

  // ============================================================================
  // FINAL CONFIGURATION
  // ============================================================================
  const handleConfigureTrip = async () => {
    if (!tripData) return;

    // Validation
    if (selectedInterests.length === 0) {
      setError("Please select at least one interest");
      return;
    }

    setLoadingConfig(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch("http://127.0.0.1:8000/api/trip/configure", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          source: tripData.source,
          destination: tripData.destination,
          distance_km: tripData.distance_km,
          travel_mode: tripData.travel_mode,
          days: tripData.days,
          pace: pace,
          budget: budget,
          selected_interests: selectedInterests,
          optional_constraints: constraints,
          ai_model: aiModel,
        }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.detail || "Failed to configure trip");
      }

      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoadingConfig(false);
    }
  };

  // ============================================================================
  // HELPER FUNCTIONS
  // ============================================================================
  const toggleInterest = (interest) => {
    setSelectedInterests((prev) =>
      prev.includes(interest)
        ? prev.filter((i) => i !== interest)
        : [...prev, interest]
    );
  };

  const handleGoBack = () => {
    window.history.back();
  };

  // Static presentation data for pace / budget cards
  const PACE_OPTIONS = [
    {
      value: "relaxed",
      label: "Relaxed",
      icon: Feather,
      detail: "1–2 places/day, late starts",
    },
    {
      value: "balanced",
      label: "Balanced",
      icon: Compass,
      detail: "3–4 places/day, moderate",
    },
    {
      value: "fast",
      label: "Fast-paced",
      icon: Zap,
      detail: "4–5 places/day, early starts",
    },
  ];

  const BUDGET_OPTIONS = [
    {
      value: "basic",
      label: "Basic",
      icon: Coins,
      detail: "Popular & free attractions",
    },
    {
      value: "premium",
      label: "Premium",
      icon: Wallet,
      detail: "Balanced experiences",
    },
    {
      value: "luxury",
      label: "Luxury",
      icon: Gem,
      detail: "Curated & exclusive",
    },
  ];

  const CONSTRAINT_LABELS = {
    avoid_early_mornings: "Avoid early mornings",
    prefer_less_walking: "Prefer less walking",
    family_friendly: "Family friendly",
    vegetarian_friendly: "Vegetarian friendly",
    photography_focus: "Photography focus",
  };

  // ============================================================================
  // RENDER: MISSING DATA CHECK
  // ============================================================================
  if (!tripData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-purple-50 flex items-center justify-center py-8 px-4">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white rounded-2xl shadow-xl border border-slate-100 p-8 text-center"
        >
          <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-gradient-to-br from-orange-500 via-pink-500 to-purple-600 flex items-center justify-center">
            <Info className="w-7 h-7 text-white" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">
            Missing Trip Data
          </h2>
          <p className="text-sm text-slate-600 mb-6">
            No trip data found. Please complete the trip preparation steps
            first.
          </p>
          <button
            onClick={() => (window.location.href = "/")}
            className="w-full px-6 py-3 bg-gradient-to-r from-orange-500 to-pink-600 text-white rounded-full font-semibold hover:shadow-lg hover:scale-[1.02] transition-all"
          >
            Return to Trip Preparation
          </button>
        </motion.div>
      </div>
    );
  }

  // ============================================================================
  // RENDER: MAIN UI
  // ============================================================================
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-purple-50 py-10 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <span className="inline-flex items-center gap-2 text-xs font-semibold tracking-wide uppercase text-orange-600 bg-orange-100 px-3 py-1 rounded-full mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            Step 2 of 3
          </span>
          <h1 className="text-3xl font-bold text-slate-900 mb-1">
            Configure Your{" "}
            <span className="bg-gradient-to-r from-orange-600 to-purple-600 bg-clip-text text-transparent">
              Trip
            </span>
          </h1>
          <p className="text-slate-600">
            Verify your trip details, then tune the preferences your AI
            itinerary will follow
          </p>
        </motion.div>

        {/* ====================================================================== */}
        {/* SECTION 1: DETAILS VERIFICATION */}
        {/* ====================================================================== */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 mb-6"
        >
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-orange-500 to-pink-600 flex items-center justify-center text-white font-bold text-sm shrink-0">
                1
              </div>
              <h2 className="text-lg font-semibold text-slate-900">
                Verify Trip Details
              </h2>
            </div>
            {detailsConfirmed && (
              <span className="inline-flex items-center gap-1.5 text-sm text-green-700 font-medium bg-green-50 px-3 py-1 rounded-full">
                <CheckCircle2 className="w-4 h-4" />
                Confirmed
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-5">
            <div className="bg-slate-50 rounded-xl p-4">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                <MapPin className="w-3.5 h-3.5" /> Source
              </div>
              <div className="font-semibold text-slate-900">
                {tripData.source.name}
              </div>
            </div>
            <div className="bg-slate-50 rounded-xl p-4">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                <MapPin className="w-3.5 h-3.5" /> Destination
              </div>
              <div className="font-semibold text-slate-900">
                {tripData.destination.name}
              </div>
            </div>
            <div className="bg-slate-50 rounded-xl p-4">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                <Route className="w-3.5 h-3.5" /> Distance
              </div>
              <div className="font-semibold text-slate-900">
                {tripData.distance_km} km
              </div>
            </div>
            <div className="bg-slate-50 rounded-xl p-4">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                <Car className="w-3.5 h-3.5" /> Travel Mode
              </div>
              <div className="font-semibold text-slate-900 capitalize">
                {tripData.travel_mode}
              </div>
            </div>
            <div className="bg-slate-50 rounded-xl p-4">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                <CalendarDays className="w-3.5 h-3.5" /> Duration
              </div>
              <div className="font-semibold text-slate-900">
                {tripData.days} days
              </div>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {!detailsConfirmed ? (
              <motion.div
                key="confirm"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-3"
              >
                <p className="text-sm text-slate-500">
                  Review the details above carefully. Once confirmed, you'll
                  need to restart trip preparation to change them.
                </p>
                <div className="flex flex-col sm:flex-row gap-3">
                  <button
                    onClick={() => setDetailsConfirmed(true)}
                    className="flex-1 inline-flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-pink-600 text-white font-semibold py-3 px-6 rounded-full hover:shadow-lg hover:scale-[1.02] transition-all"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Confirm Details
                  </button>
                  <button
                    onClick={handleGoBack}
                    className="flex-1 inline-flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-3 px-6 rounded-full transition-colors"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Go Back & Edit
                  </button>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="confirmed"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="bg-green-50 border border-green-100 rounded-xl p-3.5"
              >
                <p className="text-sm text-green-800 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  Details confirmed — configure your preferences below.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* ====================================================================== */}
        {/* SECTION 2: FINAL CONSTRAINTS (Disabled until Section 1 confirmed) */}
        {/* ====================================================================== */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: detailsConfirmed ? 1 : 0.6, y: 0 }}
          className={`bg-white rounded-2xl shadow-sm border border-slate-100 p-6 mb-6 transition-opacity ${
            !detailsConfirmed ? "pointer-events-none" : ""
          }`}
        >
          <div className="flex items-center gap-3 mb-5">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-orange-500 to-pink-600 flex items-center justify-center text-white font-bold text-sm shrink-0">
              2
            </div>
            <h2 className="text-lg font-semibold text-slate-900">
              Configure Trip Preferences
            </h2>
          </div>

          {!detailsConfirmed && (
            <div className="bg-amber-50 border border-amber-100 rounded-xl p-3.5 mb-5">
              <p className="text-sm text-amber-800 flex items-center gap-2">
                <Info className="w-4 h-4 shrink-0" />
                Confirm trip details in Section 1 before configuring
                preferences.
              </p>
            </div>
          )}

          {/* 1. Travel Pace */}
          <div className="mb-7">
            <label className="block text-sm font-semibold text-slate-900 mb-1">
              Travel pace
            </label>
            <p className="text-xs text-slate-500 mb-3">
              Determines places per day and start times
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {PACE_OPTIONS.map(({ value, label, icon: Icon, detail }) => (
                <label
                  key={value}
                  className={`relative p-4 border rounded-xl cursor-pointer transition-all ${
                    pace === value
                      ? "border-orange-400 bg-orange-50 ring-1 ring-orange-300"
                      : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                  }`}
                >
                  <input
                    type="radio"
                    name="pace"
                    value={value}
                    checked={pace === value}
                    onChange={(e) => setPace(e.target.value)}
                    disabled={!detailsConfirmed}
                    className="sr-only"
                  />
                  <Icon
                    className={`w-5 h-5 mb-2 ${
                      pace === value ? "text-orange-600" : "text-slate-400"
                    }`}
                  />
                  <div className="font-semibold text-slate-900 text-sm">
                    {label}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {detail}
                  </div>
                  {pace === value && (
                    <CheckCircle2 className="w-4 h-4 text-orange-500 absolute top-3 right-3" />
                  )}
                </label>
              ))}
            </div>
          </div>

          {/* 2. Budget Tier */}
          <div className="mb-7 pb-7 border-b border-slate-100">
            <label className="block text-sm font-semibold text-slate-900 mb-1">
              Budget tier
            </label>
            <p className="text-xs text-slate-500 mb-3">
              Affects experience style (not hotel suggestions)
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {BUDGET_OPTIONS.map(({ value, label, icon: Icon, detail }) => (
                <label
                  key={value}
                  className={`relative p-4 border rounded-xl cursor-pointer transition-all ${
                    budget === value
                      ? "border-purple-400 bg-purple-50 ring-1 ring-purple-300"
                      : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                  }`}
                >
                  <input
                    type="radio"
                    name="budget"
                    value={value}
                    checked={budget === value}
                    onChange={(e) => setBudget(e.target.value)}
                    disabled={!detailsConfirmed}
                    className="sr-only"
                  />
                  <Icon
                    className={`w-5 h-5 mb-2 ${
                      budget === value ? "text-purple-600" : "text-slate-400"
                    }`}
                  />
                  <div className="font-semibold text-slate-900 text-sm">
                    {label}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {detail}
                  </div>
                  {budget === value && (
                    <CheckCircle2 className="w-4 h-4 text-purple-500 absolute top-3 right-3" />
                  )}
                </label>
              ))}
            </div>
          </div>

          {/* 3. Interests (AI-Suggested) */}
          <div className="mb-7 pb-7 border-b border-slate-100">
            <label className="block text-sm font-semibold text-slate-900 mb-1">
              Interests
            </label>
            <p className="text-xs text-slate-500 mb-3">
              AI-suggested interests based on your destination
            </p>

            <button
              onClick={handleSuggestInterests}
              disabled={!detailsConfirmed || loadingInterests}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-orange-500 to-pink-600 disabled:from-slate-300 disabled:to-slate-300 disabled:cursor-not-allowed text-white text-sm font-semibold py-2.5 px-5 rounded-full hover:shadow-md transition-all mb-4"
            >
              {loadingInterests ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Get AI Suggestions
                </>
              )}
            </button>

            {suggestedInterests.length > 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-3"
              >
                <div className="flex flex-wrap gap-2">
                  {suggestedInterests.map((interest) => {
                    const active = selectedInterests.includes(interest);
                    return (
                      <button
                        key={interest}
                        type="button"
                        onClick={() => toggleInterest(interest)}
                        disabled={!detailsConfirmed}
                        className={`px-4 py-2 rounded-full text-sm font-medium border transition-all ${
                          active
                            ? "bg-gradient-to-r from-orange-500 to-pink-600 text-white border-transparent shadow-sm"
                            : "bg-white text-slate-600 border-slate-200 hover:border-slate-300"
                        }`}
                      >
                        {interest}
                      </button>
                    );
                  })}
                </div>

                {selectedInterests.length > 0 && (
                  <div className="bg-orange-50 border border-orange-100 rounded-xl p-3.5">
                    <span className="text-sm font-semibold text-orange-900">
                      Selected ({selectedInterests.length}):
                    </span>
                    <span className="text-sm text-orange-800 ml-2">
                      {selectedInterests.join(", ")}
                    </span>
                  </div>
                )}
              </motion.div>
            )}
          </div>

          {/* 4. Optional Constraints */}
          <div className="mb-7 pb-7 border-b border-slate-100">
            <label className="block text-sm font-semibold text-slate-900 mb-1">
              Additional preferences
            </label>
            <p className="text-xs text-slate-500 mb-3">
              Optional — refines the AI generation further
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
              {Object.keys(constraints).map((key) => (
                <label
                  key={key}
                  className={`flex items-center gap-3 p-3 border rounded-xl cursor-pointer text-sm transition-all ${
                    constraints[key]
                      ? "border-orange-300 bg-orange-50"
                      : "border-slate-200 hover:bg-slate-50"
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={constraints[key]}
                    onChange={(e) =>
                      setConstraints((prev) => ({
                        ...prev,
                        [key]: e.target.checked,
                      }))
                    }
                    disabled={!detailsConfirmed}
                    className="w-4 h-4 accent-orange-500"
                  />
                  <span className="text-slate-700 font-medium">
                    {CONSTRAINT_LABELS[key]}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* 5. AI Model Selection */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-slate-900 mb-3">
              AI model
            </label>

            <div className="space-y-2.5">
              <label
                className={`flex items-center gap-3 p-4 border rounded-xl cursor-pointer transition-all ${
                  aiModel === "gemini-flash-latest"
                    ? "border-orange-400 bg-orange-50 ring-1 ring-orange-300"
                    : "border-slate-200 hover:bg-slate-50"
                }`}
              >
                <input
                  type="radio"
                  name="model"
                  value="gemini-flash-latest"
                  checked={aiModel === "gemini-flash-latest"}
                  onChange={(e) => setAiModel(e.target.value)}
                  disabled={!detailsConfirmed}
                  className="w-4 h-4 accent-orange-500"
                />
                <div className="flex-1">
                  <div className="font-semibold text-slate-900 text-sm">
                    Gemini Flash (Standard)
                  </div>
                  <div className="text-xs text-slate-500">
                    Unlimited uses • Reliable performance
                  </div>
                </div>
              </label>

              <label
                className={`flex items-center gap-3 p-4 border rounded-xl cursor-pointer transition-all ${
                  aiModel === "gemini-2.5-flash"
                    ? "border-purple-400 bg-purple-50 ring-1 ring-purple-300"
                    : "border-amber-200 bg-amber-50/60 hover:bg-amber-50"
                }`}
              >
                <input
                  type="radio"
                  name="model"
                  value="gemini-2.5-flash"
                  checked={aiModel === "gemini-2.5-flash"}
                  onChange={(e) => setAiModel(e.target.value)}
                  disabled={!detailsConfirmed}
                  className="w-4 h-4 accent-purple-500"
                />
                <div className="flex-1">
                  <div className="font-semibold text-slate-900 text-sm flex items-center gap-2">
                    Gemini 2.5 Flash (Premium)
                    <span className="text-[10px] font-bold uppercase tracking-wide bg-gradient-to-r from-orange-500 to-purple-600 text-white px-2 py-0.5 rounded-full">
                      Premium
                    </span>
                  </div>
                  <div className="text-xs text-amber-700">
                    Limited uses per session • Enhanced quality
                  </div>
                </div>
              </label>
            </div>
          </div>

          {/* Submit Button */}
          <button
            onClick={handleConfigureTrip}
            disabled={
              !detailsConfirmed ||
              loadingConfig ||
              selectedInterests.length === 0
            }
            className="w-full inline-flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-purple-600 disabled:from-slate-300 disabled:to-slate-300 disabled:cursor-not-allowed text-white font-bold py-3.5 px-6 rounded-full hover:shadow-lg hover:scale-[1.01] transition-all"
          >
            {loadingConfig ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Processing Configuration...
              </>
            ) : (
              <>
                Finalize Configuration
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>

          {selectedInterests.length === 0 && detailsConfirmed && (
            <p className="text-xs text-red-500 mt-2 text-center">
              Select at least one interest before finalizing
            </p>
          )}
        </motion.div>

        {/* ====================================================================== */}
        {/* ERROR DISPLAY */}
        {/* ====================================================================== */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-red-50 border border-red-100 rounded-2xl p-4 mb-6"
            >
              <div className="flex items-start gap-3">
                <span className="text-xl">❌</span>
                <div>
                  <h3 className="text-sm font-semibold text-red-800 mb-1">
                    Error
                  </h3>
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ====================================================================== */}
        {/* RESULT DISPLAY */}
        {/* ====================================================================== */}
        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, y: 16, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className="bg-white rounded-2xl shadow-md border border-slate-100 overflow-hidden"
            >
              <div className="px-6 py-5 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600">
                <h2 className="text-white font-bold text-lg flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5" />
                  Configuration Complete
                </h2>
                <p className="text-white/80 text-sm mt-0.5">
                  Ready for AI itinerary generation
                </p>
              </div>

              <div className="p-6 space-y-3">
                <div className="bg-blue-50 border border-blue-100 rounded-xl p-4">
                  <h3 className="text-sm font-semibold text-blue-900 mb-1">
                    Trip Summary
                  </h3>
                  <p className="text-sm text-blue-800">
                    {tripData.source.name} → {tripData.destination.name} ·{" "}
                    {tripData.days} days · {pace} pace · {budget} budget
                  </p>
                </div>

                <div className="bg-orange-50 border border-orange-100 rounded-xl p-4">
                  <h3 className="text-sm font-semibold text-orange-900 mb-1">
                    Selected Interests ({result.interests.length})
                  </h3>
                  <p className="text-sm text-orange-800">
                    {result.interests.join(", ")}
                  </p>
                </div>

                {Object.values(result.optional_constraints).some((v) => v) && (
                  <div className="bg-purple-50 border border-purple-100 rounded-xl p-4">
                    <h3 className="text-sm font-semibold text-purple-900 mb-1">
                      Additional Preferences
                    </h3>
                    <p className="text-sm text-purple-800">
                      {Object.entries(result.optional_constraints)
                        .filter(([, v]) => v)
                        .map(([k]) => CONSTRAINT_LABELS[k] || k)
                        .join(", ")}
                    </p>
                  </div>
                )}

                {/* Full JSON (Collapsible, for debugging) */}
                <details className="group bg-slate-50 border border-slate-200 rounded-xl p-3.5">
                  <summary className="cursor-pointer text-sm font-medium text-slate-600 flex items-center justify-between">
                    View full JSON response
                    <ChevronDown className="w-4 h-4 transition-transform group-open:rotate-180" />
                  </summary>
                  <pre className="text-xs text-slate-600 mt-3 overflow-auto">
                    {JSON.stringify(result, null, 2)}
                  </pre>
                </details>

                {/* Next Step Button */}
                <button
                  onClick={() => {
                    // Store configuration in sessionStorage (persists across navigation)
                    sessionStorage.setItem(
                      "tripConfiguration",
                      JSON.stringify(result)
                    );

                    // Navigate to itinerary generation
                    window.location.href = "/itinerary-generation";
                  }}
                  className="w-full inline-flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-purple-600 text-white font-bold py-3.5 px-6 rounded-full hover:shadow-lg hover:scale-[1.01] transition-all mt-2"
                >
                  Generate Itinerary
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
