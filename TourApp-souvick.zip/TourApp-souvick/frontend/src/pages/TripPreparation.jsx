import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  MapPin,
  Search,
  Loader2,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Info,
} from "lucide-react";

/**
 * TripPreparation - Merged component for trip setup pipeline
 *
 * Data Flow:
 * Step 1 (City Selection) → Step 2 (Route Validation) → Step 3 (Travel Mode)
 *
 * State flow:
 * - selectedCity (lat/lon) → route validation API
 * - validation result (distance_km) → travel mode API
 * - days input → both validation & travel mode APIs
 */
export default function TripPreparation() {
  // ============================================================================
  // STEP 1: CITY SELECTION STATE
  // ============================================================================
  const [sourceCity, setSourceCity] = useState(null);
  const [destCity, setDestCity] = useState(null);
  const [sourceCityQuery, setSourceCityQuery] = useState("");
  const [destCityQuery, setDestCityQuery] = useState("");
  const [sourceSuggestions, setSourceSuggestions] = useState([]);
  const [destSuggestions, setDestSuggestions] = useState([]);
  const [isSearchingSource, setIsSearchingSource] = useState(false);
  const [isSearchingDest, setIsSearchingDest] = useState(false);
  const [showSourceDropdown, setShowSourceDropdown] = useState(false);
  const [showDestDropdown, setShowDestDropdown] = useState(false);

  const sourceDropdownRef = useRef(null);
  const sourceInputRef = useRef(null);
  const destDropdownRef = useRef(null);
  const destInputRef = useRef(null);

  // ============================================================================
  // STEP 2: ROUTE VALIDATION STATE
  // ============================================================================
  const [days, setDays] = useState(3);
  const [validationResult, setValidationResult] = useState(null);
  const [isValidating, setIsValidating] = useState(false);
  const [validationError, setValidationError] = useState(null);

  // ============================================================================
  // STEP 3: TRAVEL MODE STATE
  // ============================================================================
  const [preferredMode, setPreferredMode] = useState(null);
  const [modeData, setModeData] = useState(null);
  const [isLoadingModes, setIsLoadingModes] = useState(false);
  const [modeError, setModeError] = useState(null);

  // Navigation
  const [shouldNavigate, setShouldNavigate] = useState(false);

  const TRAVEL_MODES = {
    flight: { label: "Flight", icon: "✈️" },
    train: { label: "Train", icon: "🚂" },
    bus: { label: "Bus", icon: "🚌" },
    car: { label: "Car", icon: "🚗" },
  };

  // ============================================================================
  // CITY SEARCH LOGIC (SOURCE)
  // ============================================================================
  useEffect(() => {
    if (sourceCityQuery.length < 2) {
      setSourceSuggestions([]);
      setShowSourceDropdown(false);
      return;
    }

    if (sourceCity && sourceCityQuery === sourceCity.name) {
      setShowSourceDropdown(false);
      return;
    }

    setIsSearchingSource(true);
    const timeoutId = setTimeout(async () => {
      try {
        const response = await fetch(
          `http://127.0.0.1:8000/api/locations/search?q=${encodeURIComponent(sourceCityQuery)}`
        );

        if (response.ok) {
          const data = await response.json();
          setSourceSuggestions(data);
          setShowSourceDropdown(data.length > 0);
        } else {
          setSourceSuggestions([]);
          setShowSourceDropdown(false);
        }
      } catch (err) {
        setSourceSuggestions([]);
        setShowSourceDropdown(false);
      } finally {
        setIsSearchingSource(false);
      }
    }, 400);

    return () => clearTimeout(timeoutId);
  }, [sourceCityQuery, sourceCity]);

  // ============================================================================
  // CITY SEARCH LOGIC (DESTINATION)
  // ============================================================================
  useEffect(() => {
    if (destCityQuery.length < 2) {
      setDestSuggestions([]);
      setShowDestDropdown(false);
      return;
    }

    if (destCity && destCityQuery === destCity.name) {
      setShowDestDropdown(false);
      return;
    }

    setIsSearchingDest(true);
    const timeoutId = setTimeout(async () => {
      try {
        const response = await fetch(
          `http://127.0.0.1:8000/api/locations/search?q=${encodeURIComponent(destCityQuery)}`
        );

        if (response.ok) {
          const data = await response.json();
          setDestSuggestions(data);
          setShowDestDropdown(data.length > 0);
        } else {
          setDestSuggestions([]);
          setShowDestDropdown(false);
        }
      } catch (err) {
        setDestSuggestions([]);
        setShowDestDropdown(false);
      } finally {
        setIsSearchingDest(false);
      }
    }, 400);

    return () => clearTimeout(timeoutId);
  }, [destCityQuery, destCity]);

  // ============================================================================
  // CLICK OUTSIDE HANDLERS
  // ============================================================================
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        sourceDropdownRef.current &&
        !sourceDropdownRef.current.contains(event.target) &&
        sourceInputRef.current &&
        !sourceInputRef.current.contains(event.target)
      ) {
        setShowSourceDropdown(false);
      }
      if (
        destDropdownRef.current &&
        !destDropdownRef.current.contains(event.target) &&
        destInputRef.current &&
        !destInputRef.current.contains(event.target)
      ) {
        setShowDestDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // ============================================================================
  // STEP 2: ROUTE VALIDATION LOGIC
  // ============================================================================
  const handleValidateRoute = async () => {
    if (!sourceCity || !destCity) {
      setValidationError("Please select both source and destination cities");
      return;
    }

    if (sourceCity.name === destCity.name) {
      setValidationError("Source and destination must be different");
      return;
    }

    setIsValidating(true);
    setValidationError(null);
    setValidationResult(null);
    setModeData(null); // Reset step 3
    setPreferredMode(null);

    try {
      const response = await fetch("http://127.0.0.1:8000/api/route/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          source: { lat: sourceCity.lat, lon: sourceCity.lon },
          destination: { lat: destCity.lat, lon: destCity.lon },
          days: days,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.detail || `HTTP ${response.status}`);
      }

      const data = await response.json();
      setValidationResult(data);
    } catch (err) {
      setValidationError("Failed to validate route. Ensure backend is running.");
    } finally {
      setIsValidating(false);
    }
  };

  // ============================================================================
  // STEP 3: TRAVEL MODE LOGIC
  // ============================================================================
  const fetchTravelModes = async () => {
    if (!validationResult) return;

    setIsLoadingModes(true);
    setModeError(null);

    try {
      const response = await fetch("http://127.0.0.1:8000/api/travel/modes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          distance_km: validationResult.distance_km,
          days: days,
          preferred_mode: preferredMode,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.detail || `HTTP ${response.status}`);
      }

      const data = await response.json();
      setModeData(data);
    } catch (err) {
      setModeError("Failed to fetch travel modes. Ensure backend is running.");
    } finally {
      setIsLoadingModes(false);
    }
  };

  // Auto-fetch travel modes when validation succeeds
  useEffect(() => {
    if (validationResult && validationResult.feasible) {
      fetchTravelModes();
    }
  }, [validationResult, days, preferredMode]);

  // ============================================================================
  // STEP 4: PROCEED TO CONFIGURATION
  // ============================================================================
  const handleProceedToConfiguration = () => {
    // Store trip data in sessionStorage for TripConfiguration page
    const tripData = {
      source: sourceCity,
      destination: destCity,
      distance_km: validationResult.distance_km,
      travel_mode: preferredMode,
      days: days,
    };

    sessionStorage.setItem("tripData", JSON.stringify(tripData));

    // Redirect to configuration page
    window.location.href = "/trip-configuration";
  };

  // ============================================================================
  // RENDER
  // ============================================================================
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-purple-50 py-10 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <span className="inline-flex items-center gap-2 text-xs font-semibold tracking-wide uppercase text-orange-600 bg-orange-100 px-3 py-1 rounded-full mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            Step 1 of 3
          </span>
          <h1 className="text-3xl font-bold text-slate-900 mb-1">
            Plan Your{" "}
            <span className="bg-gradient-to-r from-orange-600 to-purple-600 bg-clip-text text-transparent">
              Route
            </span>
          </h1>
          <p className="text-slate-600">
            Pick your cities, confirm the route is feasible, and choose how
            you'll travel
          </p>
        </motion.div>

        {/* ====================================================================== */}
        {/* STEP 1: CITY SELECTION */}
        {/* ====================================================================== */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 mb-6"
        >
          <div className="flex items-center gap-3 mb-5">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-orange-500 to-pink-600 flex items-center justify-center text-white font-bold text-sm shrink-0">
              1
            </div>
            <h2 className="text-lg font-semibold text-slate-900">
              Select Cities
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
            {/* Source City */}
            <div className="relative">
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Source city
              </label>
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  ref={sourceInputRef}
                  type="text"
                  value={sourceCityQuery}
                  onChange={(e) => {
                    setSourceCityQuery(e.target.value);
                    if (sourceCity && e.target.value !== sourceCity.name) {
                      setSourceCity(null);
                    }
                  }}
                  onFocus={() => {
                    if (sourceSuggestions.length > 0) {
                      setShowSourceDropdown(true);
                    }
                  }}
                  placeholder="Type to search..."
                  className={`w-full pl-10 pr-9 py-2.5 border rounded-xl text-sm outline-none transition-colors focus:ring-2 focus:ring-orange-200 ${
                    sourceCity
                      ? "border-green-300 bg-green-50/60"
                      : "border-slate-200 focus:border-orange-300"
                  }`}
                />
                {isSearchingSource && (
                  <Loader2 className="w-4 h-4 text-slate-400 animate-spin absolute right-3.5 top-1/2 -translate-y-1/2" />
                )}
              </div>

              {/* Source Dropdown */}
              <AnimatePresence>
                {showSourceDropdown && sourceSuggestions.length > 0 && (
                  <motion.div
                    ref={sourceDropdownRef}
                    initial={{ opacity: 0, y: -6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                    className="absolute z-10 w-full mt-1.5 bg-white border border-slate-100 rounded-xl shadow-lg max-h-48 overflow-y-auto"
                  >
                    {sourceSuggestions.map((city, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          setSourceCity(city);
                          setSourceCityQuery(city.name);
                          setShowSourceDropdown(false);
                        }}
                        className="w-full px-4 py-2.5 text-left text-sm hover:bg-orange-50 border-b border-slate-50 last:border-b-0 flex items-center gap-2.5"
                      >
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <div>
                          <div className="font-medium text-slate-800">
                            {city.name}
                          </div>
                          <div className="text-xs text-slate-500">
                            {city.state}
                          </div>
                        </div>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>

              {sourceCity && (
                <div className="mt-1.5 text-xs text-green-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {sourceCity.name}, {sourceCity.state}
                </div>
              )}
            </div>

            {/* Destination City */}
            <div className="relative">
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Destination city
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  ref={destInputRef}
                  type="text"
                  value={destCityQuery}
                  onChange={(e) => {
                    setDestCityQuery(e.target.value);
                    if (destCity && e.target.value !== destCity.name) {
                      setDestCity(null);
                    }
                  }}
                  onFocus={() => {
                    if (destSuggestions.length > 0) {
                      setShowDestDropdown(true);
                    }
                  }}
                  placeholder="Type to search..."
                  className={`w-full pl-10 pr-9 py-2.5 border rounded-xl text-sm outline-none transition-colors focus:ring-2 focus:ring-orange-200 ${
                    destCity
                      ? "border-green-300 bg-green-50/60"
                      : "border-slate-200 focus:border-orange-300"
                  }`}
                />
                {isSearchingDest && (
                  <Loader2 className="w-4 h-4 text-slate-400 animate-spin absolute right-3.5 top-1/2 -translate-y-1/2" />
                )}
              </div>

              {/* Dest Dropdown */}
              <AnimatePresence>
                {showDestDropdown && destSuggestions.length > 0 && (
                  <motion.div
                    ref={destDropdownRef}
                    initial={{ opacity: 0, y: -6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                    className="absolute z-10 w-full mt-1.5 bg-white border border-slate-100 rounded-xl shadow-lg max-h-48 overflow-y-auto"
                  >
                    {destSuggestions.map((city, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          setDestCity(city);
                          setDestCityQuery(city.name);
                          setShowDestDropdown(false);
                        }}
                        className="w-full px-4 py-2.5 text-left text-sm hover:bg-orange-50 border-b border-slate-50 last:border-b-0 flex items-center gap-2.5"
                      >
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <div>
                          <div className="font-medium text-slate-800">
                            {city.name}
                          </div>
                          <div className="text-xs text-slate-500">
                            {city.state}
                          </div>
                        </div>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>

              {destCity && (
                <div className="mt-1.5 text-xs text-green-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {destCity.name}, {destCity.state}
                </div>
              )}
            </div>
          </div>

          {/* Days Selector */}
          <div className="mb-5">
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Trip duration:{" "}
              <span className="font-bold text-slate-900">{days} days</span>
            </label>
            <input
              type="range"
              min="1"
              max="10"
              value={days}
              onChange={(e) => setDays(Number(e.target.value))}
              className="w-full accent-orange-500"
            />
            <div className="flex justify-between text-xs text-slate-400 mt-1">
              <span>1 day</span>
              <span>10 days</span>
            </div>
          </div>

          <button
            onClick={handleValidateRoute}
            disabled={isValidating || !sourceCity || !destCity}
            className="w-full inline-flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-pink-600 disabled:from-slate-300 disabled:to-slate-300 disabled:cursor-not-allowed text-white font-semibold py-3 px-6 rounded-full hover:shadow-lg hover:scale-[1.01] transition-all"
          >
            {isValidating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Validating...
              </>
            ) : (
              <>
                Validate Route
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>

          <AnimatePresence>
            {validationError && (
              <motion.div
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                className="mt-3 p-3.5 bg-red-50 border border-red-100 rounded-xl text-sm text-red-700"
              >
                {validationError}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* ====================================================================== */}
        {/* STEP 2: ROUTE VALIDATION RESULT */}
        {/* ====================================================================== */}
        <AnimatePresence>
          {validationResult && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 mb-6"
            >
              <div className="flex items-center gap-3 mb-5">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-orange-500 to-pink-600 flex items-center justify-center text-white font-bold text-sm shrink-0">
                  2
                </div>
                <h2 className="text-lg font-semibold text-slate-900">
                  Route Validation
                </h2>
              </div>

              <div
                className={`p-5 rounded-xl border ${
                  validationResult.feasible
                    ? "bg-green-50 border-green-100"
                    : "bg-orange-50 border-orange-100"
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="font-semibold text-slate-900 flex items-center gap-2">
                    {validationResult.feasible ? (
                      <>
                        <CheckCircle2 className="w-4.5 h-4.5 text-green-600" />
                        Route Feasible
                      </>
                    ) : (
                      <>
                        <Info className="w-4.5 h-4.5 text-orange-600" />
                        Route Not Recommended
                      </>
                    )}
                  </span>
                  <span className="text-sm font-semibold text-slate-700 bg-white px-3 py-1 rounded-full">
                    {validationResult.distance_km} km
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-2">
                  <div className="bg-white rounded-lg p-3">
                    <div className="text-xs text-slate-500">Your plan</div>
                    <div className="font-bold text-slate-900">
                      {days} days
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-3">
                    <div className="text-xs text-slate-500">Recommended</div>
                    <div className="font-bold text-slate-900">
                      {validationResult.minimum_days} days
                    </div>
                  </div>
                </div>

                {validationResult.reason && (
                  <div className="text-sm text-orange-700 mt-3 flex items-start gap-2">
                    <span>💡</span>
                    {validationResult.reason}
                  </div>
                )}

                {validationResult.feasible && (
                  <div className="text-sm text-green-700 mt-3 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    Proceed to travel mode selection
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ====================================================================== */}
        {/* STEP 3: TRAVEL MODE SELECTION */}
        {/* ====================================================================== */}
        <AnimatePresence>
          {validationResult && validationResult.feasible && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 mb-6"
            >
              <div className="flex items-center gap-3 mb-5">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-orange-500 to-pink-600 flex items-center justify-center text-white font-bold text-sm shrink-0">
                  3
                </div>
                <h2 className="text-lg font-semibold text-slate-900">
                  Select Travel Mode
                </h2>
              </div>

              {isLoadingModes && (
                <div className="text-sm text-slate-500 py-4 flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Loading travel modes...
                </div>
              )}

              {modeError && (
                <div className="p-3.5 bg-red-50 border border-red-100 rounded-xl text-sm text-red-700 mb-4">
                  {modeError}
                </div>
              )}

              {modeData && (
                <>
                  {/* Recommended Modes */}
                  <div className="mb-4">
                    <div className="text-sm text-slate-500 mb-2">
                      Recommended modes for {validationResult.distance_km} km:
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {modeData.recommended_modes.map((mode) => (
                        <span
                          key={mode}
                          className="px-3 py-1 bg-green-100 text-green-800 text-sm rounded-full font-medium"
                        >
                          {TRAVEL_MODES[mode].icon} {TRAVEL_MODES[mode].label}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Mode Selection Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                    {Object.entries(TRAVEL_MODES).map(([modeKey, modeInfo]) => {
                      const isRec = modeData.recommended_modes.includes(modeKey);
                      const isSelected = preferredMode === modeKey;

                      return (
                        <button
                          key={modeKey}
                          onClick={() =>
                            setPreferredMode(isSelected ? null : modeKey)
                          }
                          className={`relative p-4 border rounded-xl text-center text-sm transition-all ${
                            isSelected
                              ? "border-orange-400 bg-orange-50 ring-1 ring-orange-300"
                              : isRec
                              ? "border-green-200 bg-white hover:border-green-300"
                              : "border-slate-200 bg-slate-50 opacity-70 hover:opacity-100"
                          }`}
                        >
                          <div className="text-2xl mb-1">{modeInfo.icon}</div>
                          <div className="font-semibold text-slate-900">
                            {modeInfo.label}
                          </div>
                          <div className="text-xs text-slate-500 mt-1">
                            {modeData.estimated_times[modeKey]}
                          </div>
                          {isRec && (
                            <div className="text-xs text-green-700 mt-1.5 font-medium">
                              ✓ Recommended
                            </div>
                          )}
                          {isSelected && (
                            <CheckCircle2 className="w-4 h-4 text-orange-500 absolute top-2.5 right-2.5" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Mode Validation Message */}
                  <AnimatePresence mode="wait">
                    {preferredMode && !modeData.preferred_mode_valid && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="p-3.5 bg-orange-50 border border-orange-100 rounded-xl text-sm text-orange-800"
                      >
                        ⚠️ {modeData.preferred_mode_reason}
                      </motion.div>
                    )}

                    {preferredMode && modeData.preferred_mode_valid && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="p-3.5 bg-green-50 border border-green-100 rounded-xl text-sm text-green-800 flex items-center gap-2"
                      >
                        <CheckCircle2 className="w-4 h-4 shrink-0" />
                        {TRAVEL_MODES[preferredMode].label} is suitable.
                        Estimated time: {modeData.estimated_times[preferredMode]}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* ====================================================================== */}
        {/* STEP 4: PROCEED TO CONFIGURATION */}
        {/* ====================================================================== */}
        <AnimatePresence>
          {validationResult && validationResult.feasible && modeData && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 mb-6"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-orange-500 to-pink-600 flex items-center justify-center text-white font-bold text-sm shrink-0">
                  4
                </div>
                <h2 className="text-lg font-semibold text-slate-900">
                  Proceed to Configuration
                </h2>
              </div>

              <p className="text-sm text-slate-600 mb-5">
                Your route is validated and travel mode is selected. Continue
                to configure your trip preferences and generate the
                itinerary.
              </p>

              <button
                onClick={handleProceedToConfiguration}
                className="w-full inline-flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-purple-600 text-white font-bold py-3.5 px-6 rounded-full hover:shadow-lg hover:scale-[1.01] transition-all"
              >
                Continue to Trip Configuration
                <ArrowRight className="w-5 h-5" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
