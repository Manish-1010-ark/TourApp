import "./App.css";
import {
  BrowserRouter as Router,
  Route,
  Routes,
} from "react-router-dom";

import LandingPage from "./pages/Home.jsx";
import ItineraryCreationPage from "./pages/ItineraryPage.jsx";
import TestItinerary from "./pages/TestItinerary.jsx";
import RouteValidation from "./pages/RouteValidation.jsx";
import TravelMode from "./pages/TravelMode.jsx";
import TripConfiguration from "./pages/TripConfiguration.jsx";
import ItineraryGeneration from "./pages/ItineraryGeneration.jsx";
import DestinationPage from "./pages/DestinationPage";
import TripPreparation from "./pages/TripPreparation.jsx";

function App() {

  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/itinerary" element={<ItineraryCreationPage />} />
        <Route path="/test" element={<TestItinerary />} /> 
        <Route path="/validate" element={<RouteValidation />} />
        <Route path="/travel-mode" element={<TravelMode />} />
        <Route path="/trip-configuration" element={<TripConfiguration />} />
        <Route path="/itinerary-generation" element={<ItineraryGeneration />} />
        <Route path="/destination/:slug" element={<DestinationPage />} />

        <Route path="/trip-prep" element={<TripPreparation />} />

      </Routes>
    </Router>
  );
}

export default App;
